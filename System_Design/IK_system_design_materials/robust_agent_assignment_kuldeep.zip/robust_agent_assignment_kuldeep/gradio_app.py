import os
import pandas as pd
from langchain_openai import ChatOpenAI
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS  # Facebook AI Similarity Search - vector database
from langchain_community.tools.tavily_search import TavilySearchResults
from langchain_core.tools import tool  # Decorator to convert functions into LangChain tools
from langchain_core.messages import SystemMessage
from langgraph.checkpoint.memory import MemorySaver  # Stores conversation history per session
from langgraph.prebuilt import create_react_agent  # Creates a ReAct (Reason+Act) agent
import gradio as gr

# --- CONFIGURATION ---
MODEL = "gpt-4o-mini"

# --- SETUP VECTOR STORE ---
# Embeddings convert text → vectors for semantic similarity search
embeddings = OpenAIEmbeddings()
retriever = None

if os.path.exists("./faiss_index"):
    try:
        # Load pre-built index containing Amazon product embeddings
        vector = FAISS.load_local(
            "./faiss_index", embeddings, allow_dangerous_deserialization=True
        )
        # Retriever fetches top-k similar documents for a query
        retriever = vector.as_retriever()
        print("Successfully loaded FAISS index.")
    except Exception as e:
        print(f"Error loading FAISS index: {e}")
else:
    print("WARNING: './faiss_index' directory not found. Amazon tool will not work.")

# --- INITIALIZE LLM ---
# temperature=0 makes responses deterministic (no randomness)
llm = ChatOpenAI(temperature=0, model=MODEL)

# --- DEFINE TOOLS ---
# @tool decorator: agent sees the function name + docstring to decide when to use it
@tool
def amazon_product_search(query: str) -> str:
    """Search the Amazon product database for reviews, ratings, and product details.

    Use this tool when the user asks about:
    - Product reviews or customer feedback
    - Product ratings and star scores
    - Comparisons between Amazon products
    - Specific product features or specifications

    Args:
        query: Natural language search query about Amazon products

    Returns:
        Relevant product information from the vector database
    """
    if not retriever:
        return "Error: Amazon product database is not available on this server."
        
    docs = retriever.invoke(query)
    return "\n\n".join([doc.page_content for doc in docs])

@tool
def search_tavily(query: str) -> str:
    """Search the web for real-time information using Tavily search engine.

    Use this tool when the user asks about:
    - Current events, news, or recent happenings
    - General knowledge not related to Amazon products
    - Up-to-date information beyond the training data
    - Facts, definitions, or explanations about any topic

    Args:
        query: Search query to find information on the web

    Returns:
        Search results including snippets, URLs, and relevant content
    """
    search_tool = TavilySearchResults(
        max_results=5,
        include_answer=True,
        include_raw_content=True,
        include_images=True,
    )
    results = search_tool.invoke(query)
    if isinstance(results, list):
        return "\n\n".join([str(r) for r in results])
    return str(results)

# Tools list passed to agent - agent chooses which tool to call based on query
tools = [search_tavily, amazon_product_search]

# --- CREATE AGENT ---
# ReAct loop: Think → Act → Observe → Repeat until answer is ready
# MemorySaver enables multi-turn conversations by persisting state
agent = create_react_agent(
    model=llm,
    tools=tools,
    checkpointer=MemorySaver()  # Each thread_id gets its own memory
)

print("Agent created successfully")

# --- GRADIO INTERFACE ---
SYSTEM_PROMPT = """You are Review Genie, a helpful AI assistant.
Guidelines:
- Use amazon_product_search for Amazon product questions.
- Use search_tavily for general queries.
- Be friendly and professional.
"""

def chat_with_agent(user_input, chat_history, session_id="default"):
    """Main chat function - sends user query through the ReAct agent."""
    if not user_input.strip():
        return "", chat_history

    try:
        # thread_id isolates conversation memory between different users/sessions
        config = {"configurable": {"thread_id": session_id}}

        # Prepend system prompt to guide agent behavior
        messages = [
            SystemMessage(content=SYSTEM_PROMPT),
            {"role": "user", "content": user_input}
        ]

        # invoke() runs the full ReAct loop until agent produces final answer
        response = agent.invoke(
            {"messages": messages},
            config=config
        )

        # Last message contains the agent's final response to user
        bot_response = response["messages"][-1].content

        # Append user/bot exchange to chat history
        chat_history.append((user_input, bot_response))
        return "", chat_history  # Clear input box, return updated history

    except Exception as e:
        chat_history.append((user_input, f"Error: {str(e)}"))
        return "", chat_history

# --- GRADIO UI ---
# gr.Blocks allows custom layout (vs gr.Interface for simple apps)
with gr.Blocks() as app:
    gr.Markdown("# Review Genie - AI Product Assistant")

    # Chatbot component displays scrollable chat history
    chatbot = gr.Chatbot(label="Chat History", height=400)

    with gr.Row():
        input_box = gr.Textbox(label="Query", placeholder="Ask me anything...", scale=4)
        session_input = gr.Textbox(label="Session ID", value="default", scale=1)

    with gr.Row():
        submit_button = gr.Button("Submit", variant="primary")
        clear_button = gr.Button("Clear Chat")

    # Submit on button click
    submit_button.click(
        chat_with_agent,
        inputs=[input_box, chatbot, session_input],
        outputs=[input_box, chatbot]
    )

    # Submit on Enter key
    input_box.submit(
        chat_with_agent,
        inputs=[input_box, chatbot, session_input],
        outputs=[input_box, chatbot]
    )

    # Clear resets chat history
    clear_button.click(lambda: ([], ""), outputs=[chatbot, input_box])

# share=True creates a public URL via Gradio's servers
app.launch(share=True)