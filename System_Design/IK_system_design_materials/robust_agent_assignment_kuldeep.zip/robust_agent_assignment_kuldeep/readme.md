# Review Genie - AI Product Assistant

An intelligent AI-powered product assistant built with LangChain, LangGraph, and Gradio. Review Genie helps users find information about Amazon products using a local FAISS vector database and performs general web searches using the Tavily API.

## Features

- **Amazon Product Search**: Queries a pre-built FAISS vector index containing Amazon product data for fast, semantic search
- **Web Search**: Integrates Tavily Search API for real-time web queries and current information
- **ReAct Agent**: Uses LangGraph's ReAct agent pattern for intelligent tool selection and reasoning
- **Conversation Memory**: Maintains session-based conversation history using MemorySaver
- **Web Interface**: Clean Gradio-based UI with session management support

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Gradio Web UI                        │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│              LangGraph ReAct Agent                      │
│              (GPT-4o-mini + MemorySaver)                │
└─────────────────────┬───────────────────────────────────┘
                      │
          ┌───────────┴───────────┐
          ▼                       ▼
┌─────────────────────┐ ┌─────────────────────┐
│  amazon_product_    │ │   search_tavily     │
│      search         │ │                     │
│  (FAISS Retriever)  │ │  (Tavily API)       │
└─────────────────────┘ └─────────────────────┘
```

## Project Structure

```
robust_agent_assignment/
├── soln.py              # Main application code
├── readme.md            # This file
└── faiss_index/         # Pre-built FAISS vector index
    ├── index.faiss      # FAISS index file
    └── index.pkl        # Metadata pickle file
```

## Prerequisites

- Python 3.8+
- OpenAI API Key
- Tavily API Key
- AWS EC2 instance (optional, for deployment)

## Deployment to AWS EC2

```bash
scp -i "kuldeep.pem" -r ./robust_agent_assignment_kuldeep/ ec2-user@ec2-98-81-139-56.compute-1.amazonaws.com:/home/ec2-user/
```

## Installation

Install pip on Amazon Linux:

```
sudo dnf install python3-pip -y
```

Set up Python virtual environment:

```bash
# 1. Create the virtual environment named 'venv'
python3 -m venv venv

# 2. Activate it (Your prompt will change to contain '(venv)')
source venv/bin/activate

# 3. Upgrade pip inside the virtual environment
pip install --upgrade pip
```

Install dependencies:

```bash
# Install all required libraries
pip install langchain langchain-openai langchain-community langgraph faiss-cpu gradio tavily-python pandas

# Install the specific version of huggingface_hub that works
pip install huggingface_hub==0.27.1
```

## Configuration

Set the required environment variables:

```bash
```bash
export OPEN_API_KEY="sk-..."
export TAVILY_API_KEY="tvly-..."
```
```

## Usage

Run the application:

```
python3 soln.py
```

Once launched, Gradio will provide:
- A local URL (e.g., `http://127.0.0.1:7860`)
- A public shareable URL (enabled via `share=True`)

### Example Queries

- "What are the best-rated wireless earbuds on Amazon?"
- "Compare reviews for noise-canceling headphones"
- "What's the latest news about AI technology?"

## API Keys
| Service | Environment Variable  | Get API Key                                      |
|---------|-----------------------|-------------------------------------------------|
| OpenAI  | `OPEN_API_KEY`        | [platform.openai.com](https://platform.openai.com/api-keys) |
| Tavily  | `TAVILY_API_KEY`      | [tavily.com](https://tavily.com/)               |

## Dependencies

| Package | Purpose |
|---------|---------|
| langchain | Core LLM framework |
| langchain-openai | OpenAI integration |
| langchain-community | Community tools (FAISS, Tavily) |
| langgraph | Agent orchestration |
| faiss-cpu | Vector similarity search |
| gradio | Web UI framework |
| tavily-python | Web search API |
| pandas | Data manipulation |
| huggingface_hub | Model/embedding utilities |

## License

This project is for educational purposes.